package gatlingTask

import io.gatling.core.structure._
import io.gatling.http.Predef._
import io.gatling.core.Predef._
import api._
import config.BaseHelper._

class OrderProduct extends Simulation {
	val scenario1: ScenarioBuilder = {
		scenario("Home Task")
			.exec(flushHttpCache)
			.exec(flushCookieJar)
			.exitBlockOnFail(
				group("Add table") {
					feed(ProductsDetails)
						.exec(
							Home.openPerfApplication(),
							addTablePage.OpenTablesPage(),
							ProductReviewPage.selectTable(),
							ProductReviewPage.addTabletoCart()
						)
				}.group("Add chair") {
					exec(
						addChairPage.OpenChairsPage(),
						ProductReviewPage.selectChair(),
						ProductReviewPage.addChairtoCart()
					)
				}.group("Place order") {
					feed(PersonalAddressDetails)
						.exec(
							CartPage.openCart(),
							CartPage.checkoutOrder(),
							FinalCheckout.selectCountry(),
							FinalCheckout.addDetailsAndOrder()
						)
				}
			)
	}
	setUp(
		scenario1.inject(atOnceUsers(1)))
		.protocols(httpProtocol)
}
