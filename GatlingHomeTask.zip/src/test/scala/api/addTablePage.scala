package api

import io.gatling.core.Predef._
import io.gatling.core.structure._
import io.gatling.http.Predef._
import config.BaseHelper._

object addTablePage {
  def OpenTablesPage(): ChainBuilder = {
    exec(http("Navigate and open to Tables Tab")
      .get(OpenTablesUrl))
  }

}
