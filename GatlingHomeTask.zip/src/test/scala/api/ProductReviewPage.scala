package api

import io.gatling.core.Predef._
import io.gatling.core.structure._
import io.gatling.http.Predef._
import config.BaseHelper._

object ProductReviewPage {
  def selectTable(): ChainBuilder = {
    exec(
      http("Select a Table")
        .get(ProductsUrl + "${table}")
        .check(css("input[name='cart_content']", "value").saveAs("c_tableCartContent"))
    )
  }
  def selectChair(): ChainBuilder = {
    exec(
      http(s"Select a Chair")
        .get(ProductsUrl + "${chair}")
        .check(css("input[name='cart_content']", "value").saveAs("c_chairCartContent"))
    )
  }

  def addChairtoCart(): ChainBuilder = {
    exec(
      http("Add Chair to cart")
        .post(AdminUrl)
        .formParam("action", "ic_add_to_cart")
        .check(status.is(200))
    )
  }

  def addTabletoCart(): ChainBuilder = {
    exec(
      http("Add Table to cart")
        .post(AdminUrl)
        .formParam("action", "ic_add_to_cart")
        .check(status.is(200))
    )
  }



}
