package api

import io.gatling.core.Predef._
import io.gatling.core.structure._
import io.gatling.http.Predef._
import config.BaseHelper._

object addChairPage {
  def OpenChairsPage(): ChainBuilder = {
    exec(http("Navigate and open chair tab")
      .get(OpenChairsUrl))
  }

}
