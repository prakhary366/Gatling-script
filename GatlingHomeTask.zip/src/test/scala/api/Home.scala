package api

import io.gatling.core.Predef._
import io.gatling.core.structure._
import io.gatling.http.Predef._
import config.BaseHelper._

object Home {
  def openPerfApplication(): ChainBuilder = {
    exec(http("Open Performance Testing Essentials Application").get(BaseUrl))
  }

}
