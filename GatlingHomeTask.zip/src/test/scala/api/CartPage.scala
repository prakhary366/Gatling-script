package api

import io.gatling.core.Predef._
import io.gatling.core.structure._
import io.gatling.http.Predef._
import config.BaseHelper._

object CartPage {
  def openCart(): ChainBuilder = {
    exec(
      http("Navigate and open Cart")
        .get(OpenCartUrl)
        .check(css("*.td-price").find(0))
        .check(css("*.td-price").find(1))
        .check(css("*.total_net"))
    )
  }

  def checkoutOrder(): ChainBuilder = {
    exec(
      session => {
        val tableID = session("c_tableCurrentProduct").as[String]
        val tableQuantity = session("c_tableCurrentQuantity").as[String]
        val chairID = session("c_chairCurrentProduct").as[String]
        val chairQuantity = session("c_chairCurrentQuantity").as[String]

        val newSession = session.set("c_cartContent", s"""{"${tableID}__":$tableQuantity,"${chairID}__":$chairQuantity}""")

        newSession
      }
    )
      .exec(
        http("Place Order")
          .post(CheckoutUrl)
          .formParam("cart_content", "${c_cartContent}")
          .formParam("p_id[]", "${c_tableCurrentProduct}__")
          .formParam("p_id[]", "${c_chairCurrentProduct}__")
          .formParam("total_net", "${c_totalPrice}")
          .formParam("shipping", "order")
          .check(regex("""<option value="[A-Z]{2}" >${country} - (.*?)</option>""").saveAs("c_countryCode"))
          .check(css("input[name='ic_formbuilder_redirect']", "value").saveAs("c_redirectThankYou"))
      )
  }

}
